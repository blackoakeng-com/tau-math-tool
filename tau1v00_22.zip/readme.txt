Unzip tau distribution file.
Click tauInstall.exe.
Register your copy.
A desktop shortcut icon will appear quickly when tau is installed.
Install files may be deleted.